package com.zensar.training.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class CountLinesInFileTask implements Runnable{

	@Override
	public void run()  {
		RandomAccessFile randomAccessFile = null;
		try {
			randomAccessFile=new RandomAccessFile("Intro.txt","r");
		} catch (FileNotFoundException e) {
						e.printStackTrace();
		}
		int count=0;
		while(true) {
			try {
				String str=randomAccessFile.readLine();
				if(str==null)
					break;
				count++;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println(Thread.currentThread().getName()+" : "+count);
		}

		
	}

}
